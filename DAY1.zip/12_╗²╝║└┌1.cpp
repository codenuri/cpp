// 5_생성자1.cpp 80page ~
#include <iostream>
#include <string>

class Person
{
public:
	std::string name;
	int  age;
};
int main()
{
	Person p = { "kim", 28 };

}



