﻿#include <iostream>

// C++ 언어는 안전한 캐스팅을 위해서 
// 4개의 캐스팅 연산자 제공

// 1. static_cast
// 2. reinterpret_cast
// 3. const_cast
// 4. dynamic_cast

// static_cast : 논리적으로 맞고 위험하지 않은 경우만 허용
//          void*=> 다른 타입*,
//			상속관계의 캐스팅 등.
//          반드시 연관성이 있어야 한다


int main()
{
	double d = 3.4;
	int    n = d;

	int* p1 = malloc(100);    
}

