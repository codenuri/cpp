#include <iostream>

int main()
{
	std::cout << "hello, cpp\n";
}