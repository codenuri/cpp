﻿// 3_변수5
// 30 page ~

// type alias 만들기

using DWORD = int;

int main()
{
	DWORD n;
}

