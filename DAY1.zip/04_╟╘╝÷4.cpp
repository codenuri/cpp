﻿// C++ 함수 특징 4. inline   .. 36page

       int add1(int a, int b) { return a + b; }
inline int add2(int a, int b) { return a + b; }

int main()
{
	int n1 = add1(1, 2);  
	int n2 = add2(1, 2);  
}
