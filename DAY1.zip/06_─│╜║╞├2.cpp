#include <iostream>

int main()
{
	const int c = 10;

	int* p = &c;

	std::cout << c  << std::endl;
	std::cout << *p << std::endl;
}
