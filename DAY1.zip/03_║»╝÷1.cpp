﻿// 3_변수1
#include <iostream>

// C++ 은 C언어의 변수 관련 문법을 더욱 발전시켰습니다.
// 교재 22 page ~

struct Point 
{
	int x, y; 
};

int main()
{
	bool b = true;
	long long n = 0;

	int n1 = 1;
	int n2 = 1'000'000;
	
	struct Point p1;
	Point p2; 

	int n3; 
}
