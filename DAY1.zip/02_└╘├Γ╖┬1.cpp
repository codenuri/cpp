﻿#include <cstdio>
#include <iostream> 

// 13 page

int main()
{
	int n = 10;

	// C style 입출력
	printf("n = %d\n", n); // C style
	scanf("%d", &n);	   // 입력

	// C++ style
}
