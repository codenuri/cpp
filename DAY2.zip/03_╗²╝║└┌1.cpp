// 5_생성자1.cpp 80page ~
#include <iostream>

class Car
{
public:
	int color;
	int speed;
};

int main()
{
	Car c = { 10, 80};

}



