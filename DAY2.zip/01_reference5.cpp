// 인자로 전달된 원본 변수를 수정되지 않게 하려고 합니다.
// 다음 f1, f2 중 좋은 코드는 ?

void f1(int n) 
{ 
	int k = n; 
}
void f2(const int& r) 
{ 
	int k = r; 
}
int main()
{
	int x = 10;
	f1(x);
	f2(x);
}

