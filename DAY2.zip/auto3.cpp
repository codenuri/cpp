template<typename T>
T f1(T a)
{
	return 0;
}

auto f2(auto a)
{
	return 0;
}

int main()
{
	f1(3.4);
	f2(3.4);
}