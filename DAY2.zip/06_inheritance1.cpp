﻿#include <iostream>

class Student 
{	
	int    age;
	int    id;
};
class Professor
{
	int    age;
	int    major;
};

int main()
{
	Student s;
	Professor p;
}
