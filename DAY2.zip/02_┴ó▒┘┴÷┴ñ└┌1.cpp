// 4_접근지정자 - 76page~
#include <iostream>

struct Car
{
	int speed;		
};

int main()
{
	Car c;

	c.speed = -10;

				 
}
