﻿#include <iostream>
#include <string>

class People 
{
	std::string name;
	int age;
public:
	People(const std::string& n, int a)
	{
		name = n;
		age = a;
	}
};
int main()
{
	People p("kim", 20);
}




