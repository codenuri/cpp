#include <iostream>

int main()
{
	int n1 = 10;

	int* p1 = &n1;
	int& r1 = n1;

	*p1 = 20;
	r1 = 20;

	int* p2;
	int* p3 = nullptr;

	int& r2;
	int& r3 = nullptr;
}

void f1(int* p) 
{
	*p = 10;
}
void f2(int& r) 
{
	r = 10;
}