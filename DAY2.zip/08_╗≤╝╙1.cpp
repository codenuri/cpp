﻿// 5_상속1.cpp   133page ~
#include <iostream>

class Student 
{	
	int    age;
	int    id;
};
class Professor
{
	int    age;
	int    major;
};

int main()
{
	Student s;
	Professor p;
}
