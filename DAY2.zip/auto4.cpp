template<typename T>
T square1(T a) 
{
	return a * a;
}

int main()
{
	square(3);
	square(3.3);
}