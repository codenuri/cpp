// 인자로 auto 를 사용하는 경우

void f1(auto n) 
{

}

int main()
{
	f1(10);
	f1(2.2);
}