#include <cstdio>

// RAII 기술

int main()
{
	FILE* f = fopen("a.txt", "w");

	fclose(f);
}