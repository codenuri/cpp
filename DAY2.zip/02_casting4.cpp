﻿#include <iostream>

// reinterpret_cast 
// 1. 서로 다른 타입의 주소 변환
// 2. 정수 <=> 주소 사이의 변환

int main()
{	
	int n = 3;

	double* p1 = &n;


	
}

