#include <string>

int main()
{
	int a = 10;
	int b;
	b = 10;

	//-------------------------
	const int c1 = 10;
	const int c2;
	c2 = 10;


}