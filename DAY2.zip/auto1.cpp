int main()
{
	// 변수 선언시 auto 사용가능 - C++11 에서 도입
	auto n = 3;
}

// 함수 반환 타입으로 auto 사용 - C++14 에서 도입
auto foo()
{
	return 3;
}

// 함수 인자로 auto 사용 - C++20 에서 도입
void goo(auto arg)
{
}

// C++ 컴파일러 사용시 언어 버전 지정하는 방법

// #1. g++, clang++
// g++ 소스이름.cpp -std=c++20

// #2. visual studio 사용시 언어 버전 지정하는 방법
// => 프로젝트 메뉴 -> DAY2 설정 메뉴 선택
// => 나타나는 창에서 일반 설정에서 "C++ 언어 버전" 에서 설정
