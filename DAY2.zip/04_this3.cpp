class Dialog 
{
public:
	void close(int code) {}
};

void foo(int n) {}

int main()
{
	void(*f1)(int) = &foo;
	void(*f2)(int) = &Dialog::close;
	
}