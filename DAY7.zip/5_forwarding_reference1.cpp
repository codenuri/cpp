
// forwarding reference 란 ?
// => 함수 템플릿 인자로 사용되는 T&&

template<typename T> void chronomety(T&& a)
{
}

int main()
{

}