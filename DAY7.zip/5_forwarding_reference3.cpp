// forwarding_reference
void f1(int&  r) {}
void f2(int&& r) {}

int n = 0;
f1(n);
f1(3);


template<typename T> void f3(T& a)
{
}

template<typename T> void f4(T&& a)
{
}

int main()
{
	int n = 3;
	f4(3);
	f4(n);
}