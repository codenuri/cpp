#include <iostream>
#include <array>

int main()
{
	std::array<int, 10> arr = { 1,2,3,4,5,6,7,8,9,10 };

	// arr 의 모든 요소를 순회 하는 방법



	// 

}