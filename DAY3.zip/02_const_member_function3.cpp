#include <iostream>
#include <sstream> // std::ostringstream
#include <string>

class Point
{
public:
	int x, y;
	Point(int a, int b) : x{a}, y{b} {}

	std::string to_string()
	{
		std::ostringstream oss;
		oss << "Point{x=" << x << ", y=" << y << "}";
		std::string s = oss.str();
		return s;
	}	
};
int main() 
{
	Point p{1, 2};
	
	std::cout << p.to_string() << std::endl;
	std::cout << p.to_string() << std::endl;
}
