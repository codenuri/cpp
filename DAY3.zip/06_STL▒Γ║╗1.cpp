#include <iostream>
#include <vector>

int main()
{
	int x[5] = { 1,2,3,4,5 };

	std::vector<int> v = { 1,2,3,4,5 };

	std::cout << x[0] << std::endl; 
	std::cout << v[0] << std::endl; 

	v.resize(10);

	std::cout << v.size() << std::endl; // 10
}

