#include <iostream>
#include <array>

int main()
{
	std::array<int, 10> arr = { 1,2,3,4,5,6,7,8,9,10 };
	
	// 1. past the end

	auto p1 = arr.begin();	
	auto p2 = arr.end();		

	*p1 = 10;	// ?
	*p2 = 10;	// ?

	while (p1 != p2)
	{
		std::cout << *p1 << std::endl;
		++p1;
	}
}