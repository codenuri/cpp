﻿class Animal
{
public:	int age;
};
class Dog : public Animal
{
public:	int color;
};
class Cat : public Animal
{
public:	int speed;
};


void new_year(Dog* p) 
{
	++(p->age);
}


int main()
{
	Dog d;
	Cat c;

	new_year(&d);
	new_year(&c);
}
