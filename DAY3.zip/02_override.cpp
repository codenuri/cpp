﻿// 7_가상함수2.cpp  147 page ~

class Shape
{
public:
	virtual void draw() {};
	virtual void clone() const {};
	virtual void move() {};
};
class Rect : public Shape
{
public:
	virtual void draw()  {};

	
	virtual void clone() {};
	virtual void move(int n) {};
};
int main()
{

}
