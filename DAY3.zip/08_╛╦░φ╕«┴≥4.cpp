#include <iostream>
#include <vector>
#include <array>

int main()
{
	std::array<int, 10> arr = { 1,2,3,4,5,6,7,8,9,10 };
		
	// arr 에서 짝수를 0 으로 변경해 보세요	 



	for (auto e : arr)
		std::cout << e << ", "; // 1,0,9,0,3,0,7,3,9,0
}