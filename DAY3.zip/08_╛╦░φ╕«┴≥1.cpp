#include <iostream>
#include <vector>
#include <list>
#include <algorithm>

int main()
{
	std::list<int>   s = { 1,2,3,4,5,6,7,8,9,10 };
	std::vector<int> v = { 1,2,3,4,5,6,7,8,9,10 };

	// 컨테이너에서 3을 찾고 싶다.

	// 방법 #1. 멤버 함수 find 제공
	s.find(3);
	v.find(3);
	

	// 방법 #2. 
	std::find(s.begin(), s.end(), 3);
	std::find(v.begin(), v.end(), 3);
	


}
