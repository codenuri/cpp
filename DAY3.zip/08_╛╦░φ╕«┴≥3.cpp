#include <iostream>
#include <algorithm>
#include <array>

int main()
{
	std::array<int, 10> arr = { 1,2,3,4,5,6,7,8,9,10 };


	auto ret1 = std::find(arr.begin(), arr.end(), 3); 

	if (ret1 == arr.end())
	{
	}
	else
	{
		std::cout << *ret1 << std::endl;
	}
}