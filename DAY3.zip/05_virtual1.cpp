﻿#include <iostream>

class Animal
{
public:
	void cry() { std::cout << "Animal cry" << std::endl; } // 1
};

class Dog : public Animal
{
public:
	void cry() { std::cout << "Dog cry" << std::endl; }  // 2
};

int main()
{
	Animal a; a.cry(); 
	Dog    d; d.cry(); 

	Animal* p = &d;		

	p->cry();
}

