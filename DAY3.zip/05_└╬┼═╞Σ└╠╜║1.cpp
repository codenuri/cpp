#include <iostream>

class Camera
{
public:
	void start_recording() { std::cout << "Start recording in HD quality\n"; }
	void stop_recording()  { std::cout << "Stop recording in HD quality\n"; }
};

class Car 
{
	Camera* cam;
public:
	void install_camera(Camera* c) { cam = c;}

	void go()   { cam->start_recording();}
	void stop() { cam->stop_recording();}
};

int main()
{
	Car car;
	Camera cam;

	car.install_camera(&cam);
	car.go();
	car.stop();
}

