#include <iostream>
#include <array>
#include <algorithm> 

int main()
{
	std::array<int, 10> arr = { 1,2,3,4,5,6,7,8,9,10 };

	// arr의 모든 요소를 뒤집어 보세요
	

	for (auto e : arr)
		std::cout << e << ", ";
	std::cout << std::endl;

	
	// arr 에서 3 을 -1 로 변경해 보세요
	

	for (auto e : arr)
		std::cout << e << ", ";
	std::cout << std::endl;

	
}