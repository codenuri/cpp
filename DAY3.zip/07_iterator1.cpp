#include <iostream>
#include <list>

int main()
{
	int x[10] = { 1,2,3,4,5,6,7,8,9,10 };

	// 배열은 시작 주소를 알면 ++ 연산을 사용해서 모든 요소를 순회 할수 있습니다.
	int* p1 = x;

	// 하지만 linked list 는 연속된 메모리가 아니라서
	// 1번째 요소의 시작 주소를 알아도 ++로 모든 요소를 순회 할수 없습니다.
	std::list<int> s = { 1,2,3,4,5,6,7,8,9,10 };

	// 하지만 linked list 라도 반복자를 꺼내면 모든 요소를 순회 할수 있습니다.
	auto p2 = s.begin();

	++p2;
	++p2;

	std::cout << *p2 << std::endl; // 3

}