// 1_��������6
#include <iostream>
#include <string>

int main()
{
	std::string s1 = "abcd";
	std::string s2 = "ABCD";

	bool b = (s1 == s2);

	std::cout << b << std::endl;  
}