#include <iostream>

// 게임의 규칙 : 캐릭터는 아이템을 획득하면 모든 동작이 변경되어야 합니다.
class Character
{
	int gold;
	int item;
public:
	void run()    { std::cout << "run" << std::endl; }
	void attack() { std::cout << "attack" << std::endl; }
};

int main()
{
	Character* p = new Character;
	p->run();
	p->attack();
}



