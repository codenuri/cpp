#include <iostream>

template<typename T>
class vector
{
	T* buff;
	std::size_t size;
public:
	void resize(int sz)
	{
		// resize 구현을 위해서 메모리 재할당이 필요하다고 가정해 봅시다.
		// 어떤 방법으로 메모리를 할당하면 좋을까요 ?
		// new / malloc / system call / windows api ?

		buff = new T[sz];

		delete[] buff;
	}
};

int main()
{
}