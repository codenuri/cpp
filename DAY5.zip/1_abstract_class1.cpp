class Shape
{
public:
	virtual void draw()  = 0;
};
class Rect : public Shape
{
public:
};
int main()
{
	Shape s;  // ?
	Shape* p; // ?
	Rect  r;  // ?	
}


