#include <iostream>

// 파워 포인트 값은 프로그램을 객체지향으로 만든다고 생각해 봅시다.


int main()
{
	
}