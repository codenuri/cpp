// lvalue, rvalue 개념
// => 변수가 아닌 expression 에 부여되는 개념

// expression : 하나의 값을 만드는 코드 집합
// exression 이 만드는 하나의 값 : result

// result 의 2가지 특징 
// => 1. type
// => 2. value category

int main()
{
	int n = 1;

	(n + 2) * 3; 

}