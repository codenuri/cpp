int x = 0;

int  f1() { return x;} // ?
int& f2() { return x;} // ?

// rvalue 의 특징
int main()
{
	int n = 1;

	(n = 2) = 1;	// ?
	(n + 2) = 1;	// ?

	int* p1 = &(n = 2); // ?
	int* p2 = &(n + 2); // ?

	f1() = 1; // ?
	f2() = 1; // ?
}