#include <iostream>

void foo(Point&  pt) {std::println("1. Point&"); }
void foo(Point&& pt) {std::println("2. Point&&");}
void foo(const Point&  pt) {std::println("3. const Point&");}

int main()
{
	Point pt{1, 2};

	foo( pt );			// 

	foo( Point{1,2} );	// 

}


