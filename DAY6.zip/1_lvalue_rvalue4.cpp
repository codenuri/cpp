int main()
{
	const int c = 1;

	c = 1; 	// ?
}