class Point
{
public:
	int x, y;
	Point(int a, int b) : x{a}, y{b} { }	
};

Point pt{1, 1};

Point foo()
{
	return pt;
}

int main()
{
	foo().x =10;
}