int main()
{
	int n = 1;

	n = 1; 	// ?
	1 = n;	// 
}
