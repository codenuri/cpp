#include <iostream>

template<typename T> void foo(T&& arg)
{
	
}
int main()
{
	int n = 10;

	foo(n);  //
	foo(10); //
}




