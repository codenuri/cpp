struct Point 
{ 
	int x;
	int y; 
};

int main()
{
	Point pt{1, 2};

	Point& r1 = pt;					// 
	Point& r2 = Point{1, 2};		// 

	const Point& r3 = pt;			// 
	const Point& r4 = Point{1, 2};	// 
}